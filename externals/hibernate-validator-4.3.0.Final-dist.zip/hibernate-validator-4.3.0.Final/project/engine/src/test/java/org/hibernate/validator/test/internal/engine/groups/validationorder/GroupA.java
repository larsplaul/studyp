package org.hibernate.validator.test.internal.engine.groups.validationorder;

/**
 * @author Hardy Ferentschik
 */
interface GroupA {
}


