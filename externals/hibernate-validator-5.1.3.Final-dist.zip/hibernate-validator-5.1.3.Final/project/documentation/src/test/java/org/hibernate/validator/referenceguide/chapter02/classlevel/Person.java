package org.hibernate.validator.referenceguide.chapter02.classlevel;

public class Person {
}
