package org.hibernate.validator.referenceguide.chapter10.cdi.methodvalidation.configuration;

public class Customer {
}
