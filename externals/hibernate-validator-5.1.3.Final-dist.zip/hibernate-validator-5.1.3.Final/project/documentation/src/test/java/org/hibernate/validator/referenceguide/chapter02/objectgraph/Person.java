package org.hibernate.validator.referenceguide.chapter02.objectgraph;

import javax.validation.constraints.NotNull;

public class Person {

	@NotNull
	private String name;

	//...
}